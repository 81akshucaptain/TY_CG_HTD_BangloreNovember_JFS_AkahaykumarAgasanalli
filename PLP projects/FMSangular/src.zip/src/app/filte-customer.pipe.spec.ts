import { FilteCustomerPipe } from './filte-customer.pipe';

describe('FilteCustomerPipe', () => {
  it('create an instance', () => {
    const pipe = new FilteCustomerPipe();
    expect(pipe).toBeTruthy();
  });
});
