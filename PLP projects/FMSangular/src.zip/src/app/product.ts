interface Products {
    productId?: number;
    name: string;
    cost: number;
    quantity: number;
    productClass: string;
}
