interface Customers {
    customerId?: number;
    name: string;
    town: string;
    postal: number;
    email: string;
    phone: string;
    password: string;
}
