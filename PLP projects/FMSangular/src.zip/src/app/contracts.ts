interface Contracts {
    contractId?: number;
    customerId: number;
    productId: number;
    haulierId: string;
    deliveryDate: string;
    qunatity: number;
    status: string;
}
