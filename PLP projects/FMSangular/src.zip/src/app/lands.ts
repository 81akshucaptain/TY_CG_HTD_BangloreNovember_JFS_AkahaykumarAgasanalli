interface Lands {
    landId ?: number;
    landSize: number;
    landResources: string;
    landLocation: string;
}
