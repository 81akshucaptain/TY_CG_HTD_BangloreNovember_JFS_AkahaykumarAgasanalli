import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scheduler-home',
  templateUrl: './scheduler-home.component.html',
  styleUrls: ['./scheduler-home.component.css']
})
export class SchedulerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
