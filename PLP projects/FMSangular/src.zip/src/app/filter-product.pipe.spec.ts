import { FilterProductPipe } from './filter-product.pipe';

describe('FilterProductPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterProductPipe();
    expect(pipe).toBeTruthy();
  });
});
