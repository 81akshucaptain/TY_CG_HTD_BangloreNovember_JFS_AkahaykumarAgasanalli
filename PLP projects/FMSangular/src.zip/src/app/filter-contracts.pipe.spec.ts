import { FilterContractsPipe } from './filter-contracts.pipe';

describe('FilterContractsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterContractsPipe();
    expect(pipe).toBeTruthy();
  });
});
