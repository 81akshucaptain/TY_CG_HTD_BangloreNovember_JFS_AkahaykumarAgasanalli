import { FilterLandsPipe } from './filter-lands.pipe';

describe('FilterLandsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterLandsPipe();
    expect(pipe).toBeTruthy();
  });
});
